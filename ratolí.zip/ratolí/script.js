let miPantalla;
let ctx;
let FPS = 50
let imatgeProta;
let imatgeSecundari

let anchoF = 50;
let altoF = 50;

let herba = '#90bd30';//0
let aigua = '#56a2f7';//2
let terra = '#905010';//3
let pared = '#646464';//1
let llave = '#FFFF00';//4
let puerta = '#ff0000';//5
let borde = '#FFA500';//6

let escenari = [
    [6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6],
    [6, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6],
    [6, 2, 2, 2, 0, 0, 0, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 0, 0, 6],
    [6, 3, 2, 2, 0, 0, 3, 3, 3, 3, 3, 3, 3, 3, 4, 3, 3, 3, 3, 0, 0, 6],
    [6, 3, 3, 2, 2, 0, 3, 3, 3, 3, 3, 1, 1, 1, 1, 1, 1, 3, 3, 3, 0, 6],
    [6, 3, 3, 2, 2, 0, 3, 3, 3, 3, 1, 0, 0, 0, 0, 0, 0, 1, 1, 3, 3, 6],
    [6, 3, 3, 3, 2, 2, 3, 3, 3, 3, 1, 0, 3, 3, 3, 3, 0, 0, 1, 3, 3, 6],
    [6, 0, 3, 3, 2, 2, 2, 3, 3, 3, 1, 0, 3, 3, 3, 3, 3, 0, 0, 1, 3, 6],
    [6, 0, 0, 3, 3, 3, 2, 3, 3, 1, 0, 3, 3, 3, 3, 3, 3, 3, 0, 1, 3, 6],
    [6, 0, 0, 0, 3, 1, 1, 3, 3, 1, 3, 3, 3, 0, 0, 0, 3, 3, 3, 3, 3, 6],
    [6, 0, 0, 0, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 0, 0, 3, 3, 3, 3, 5, 6],
    [6, 0, 0, 3, 3, 1, 1, 3, 3, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 6],
    [6, 0, 3, 3, 2, 2, 2, 3, 3, 1, 0, 3, 3, 3, 3, 3, 3, 3, 0, 1, 3, 6],
    [6, 3, 3, 3, 2, 2, 3, 3, 3, 3, 1, 0, 3, 3, 3, 3, 0, 0, 0, 1, 3, 6],
    [6, 3, 3, 2, 2, 0, 3, 3, 3, 3, 1, 0, 0, 0, 0, 0, 0, 1, 1, 3, 3, 6],
    [6, 3, 2, 2, 0, 0, 0, 3, 3, 3, 3, 1, 1, 1, 1, 1, 1, 3, 3, 3, 0, 6],
    [6, 2, 2, 0, 0, 0, 0, 0, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 0, 0, 6],
    [6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6]
]
function inicializar() {
    miPantalla = document.getElementById("pantalla")
    ctx = pantalla.getContext('2d');
    imatgeProta = new Image();
    imatgeProta.src = 'pac.png'
    imatgeSecundari = new Image();
    imatgeSecundari.src = 'fantasmataronja.png'


    setInterval(function () {
        principal()
    }, 1000 / FPS)

}

function borrarPantalla() {
    miPantalla.width = 1100;
    miPantalla.height = 900;
}

function principal() {

    borrarPantalla()
    dibuixaEscenari();
    p4.dibuixa()//prota
    p1.dibuixa()
    p2.dibuixa()
    p3.dibuixa()
    p1.mueve()
    p2.mueve()
    p3.mueve()

}

let personaje = function (x, y, ancho, alto,) {
    this.x = x;
    this.y = y;
    this.alto = alto
    this.ancho = ancho
    this.retraso = 10
    this.fotograma = 0

    this.colisio = function(y,x) {
  
        let choque = false;
        if (escenari[y][x] == 1 || escenari[y][x] == 2 || escenari[y][x]==0 || escenari[y][x] == 6) {
            choque = true;
        }
       
        return choque;
    }


    this.dibuixa = function () {
        ctx.drawImage(imatgeSecundari, this.x, this.y)
    }

    this.mueve = function () {
        p4.muerte(this.y, this.x)
    if (this.fotograma < this.retraso){
     this.fotograma++
    }else{
        this.fotograma = 0;
        let posicio = Math.floor(Math.random() * 4);
        console.log(posicio)
        if (posicio == 0) {
            if (this.colisio((this.y - 50) / 50, (this.x) / 50)) {

            } else {
                this.y -= 50
            }
        }
        if (posicio == 1) {
            if (this.colisio((this.y + 50) / 50, (this.x) / 50)) {

            } else {
                this.y += 50
            }
        }
        if (posicio == 2) {
            if (this.colisio((this.y / 50), (this.x + 50) / 50)) {

            } else {
                this.x += 50
            }
        }
        if (posicio == 3) {
            if (this.colisio((this.y / 50), (this.x - 50) / 50)) {

            } else {
                this.x -= 50
            }
        }
    }

       
    }
}
    

let p1 = new personaje(400, 150, 50, 50, 10);
let p2 = new personaje(700, 400, 25, 25, 10);
let p3 = new personaje(700, 550, 100, 100, 10);


let prota = function (x, y, ancho, alto) {
    this.x = x;
    this.y = y;
    this.alto = alto
    this.ancho = ancho
    this.llave = false;

    this.muerte  = function(y,x){
        if(this.y == y && this.x ==x){
            alert("HAS MUERTO")
            this.x = 200
            this.y = 500
            escenari[3][14]=4
            this.llave = false;
    }
}

    this.colisio = function(y,x) {
  
        let choque = false;
        if (escenari[y][x] == 1 || escenari[y][x] == 2 || escenari[y][x]==0 || escenari[y][x] == 6) {
            choque = true;
        }
        if (escenari[y][x] == 4){
                this.llave = true
                alert("Has cogido la llave")
                escenari[y][x] = 3
        }
            
        if (escenari[y][x] == 5) {
            if (this.llave == true) {
                alert("Has ganado")
            } else {
                alert("Te falta la llave")
            }

        }
        return choque;
    }

    this.dibuixa = function () {
        ctx.drawImage(imatgeProta, this.x, this.y)
    }
    

    this.arriba = function () {
        if (this.colisio((this.y - 50) / 50, this.x / 50)) {

        } else {
            this.y -= 50
        }

    }
    this.abajo = function () {
        if (this.colisio((this.y + 50) / 50, this.x / 50)) {

        } else {
            this.y += 50
        }

    }
    this.derecha = function () {

        if (this.colisio((this.y) / 50, (this.x + 50) / 50)) {

        } else {
            this.x += 50
        }

    }
    this.izquierda = function () {
        if (this.colisio((this.y / 50), (this.x - 50) / 50)) {

        } else {
            this.x -= 50
        }

    }


}

let p4 = new prota(200, 500, 100, 100);


document.addEventListener("keydown", function (tecla) {
    if (tecla.key == "ArrowUp") {
        p4.arriba();
    }
    if (tecla.key == "ArrowDown") {
        p4.abajo();
    }
    if (tecla.key == "ArrowRight") {
        p4.derecha();
    }
    if (tecla.key == "ArrowLeft") {
        p4.izquierda();
    }
})
function dibuixaEscenari() {
    for (let y = 0; y < 18; y++) {
        for (let x = 0; x < 22; x++) {
            if (escenari[y][x] == 0) {
                color = herba
            }
            if (escenari[y][x] == 1) {
                color = pared
            }
            if (escenari[y][x] == 2) {
                color = aigua
            }
            if (escenari[y][x] == 3) {
                color = terra
            }
            if (escenari[y][x] == 4) {
                color = llave
            }
            if (escenari[y][x] == 5) {
                color = puerta
            }
            if (escenari[y][x] == 6) {
                color = borde
            }
            ctx.fillStyle = color;
            ctx.fillRect(x * anchoF, y * altoF, anchoF, altoF)
        }
    }
}//128*64
//crear protagonista amb altre color que se mogui amb 4 fletxes

//variable edat, parametre edat, hola me llamo tal y edad es tal. modificar de sa linia 25 a 42
//miPantalla.addEventListener('mousedown',ratonPulsado);
//miPantalla.addEventListener('mouseup',ratonSoltado);
//miPantalla.addEventListener('mousemove',ratonMueve);
/*
function ratonPulsado(){
    console.log("Has pulsado el ratón")
}
function ratonSoltado(){
    console.log("Has soltado el ratón")
}
function ratonMueve(e){
    let x = e.pageX
    let y = e.pageY
    console.log("X: "+x+" - Y: "+y)
}


let personaje = function(x,y,nom,edat){
this.x = x
this.y = y
this.nombre = nom
this.anys = edat
this.hablar = function(){
    console.log("Hola me llamo "+this.nombre)
}
this.mostraredat = function(){
    console.log("Mi edad es "+this.anys)
}
this.dibuixa = function(){
    ctx.fillStyle = "#F98404"
    ctx.fillRect(this.x,this.y,50,50);
}
}
let p1 = new personaje(10,20,"Félix",15);
let p2 = new personaje(100,200,"Yared",18);
let p3 = new personaje(50,100,"Mateo",21);

p1.hablar();
p1.mostraredat();
p2.hablar();
p2.mostraredat();
p3.hablar();
p3.mostraredat();

   this.arriba = function(){
        if(escenari[(this.y-50)/50][this.x/50]!=2 && escenari[(this.y-50)/50][this.x/50]!=1 && escenari[(this.y-50)/50][this.x/50]!=0){
            this.y-=50
        }
    }
    this.abajo = function(){
        if(escenari[(this.y+50)/50][this.x/anchoF]!=2 && escenari[(this.y+50)/50][this.x/anchoF]!=1 && escenari[(this.y+50)/50][this.x/anchoF]!=0){
        this.y+=50} 
    }
    this.derecha = function(){
        if(escenari[(this.y)/50][(this.x+50)/anchoF]!=2 && escenari[(this.y)/50][(this.x+50)/anchoF]!=1 && escenari[(this.y)/50][(this.x+50)/anchoF]!=0){
        this.x+=50} 
    }
    this.izquierda = function(){
        if(escenari[(this.y)/50][(this.x-50)/anchoF]!=2 && escenari[(this.y)/50][(this.x-50)/anchoF]!=1 && escenari[(this.y)/50][(this.x-50)/anchoF]!=0){
        this.x-=50} 
    }
    
*/